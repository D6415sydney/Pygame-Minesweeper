Before using the application install the provided font (Press Start 2P) on your computer.

All controls are carried from original Minesweeper.